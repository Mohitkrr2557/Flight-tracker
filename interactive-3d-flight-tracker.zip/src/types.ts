export interface Airport {
  iata: string;
  icao: string;
  name: string;
  city: string;
  country: string;
  lat: number;
  lon: number;
}

export interface AirlineInfo {
  name: string;
  iata?: string | null;
  icao?: string | null;
  country?: string | null;
}

export interface LiveState {
  icao24: string;
  lat: number | null;
  lon: number | null;
  altitudeFt: number | null; // null when unknown, 0 when on ground
  groundSpeedKts: number | null;
  headingDeg: number | null; // true track, degrees
  verticalRateFpm: number | null;
  squawk: string | null;
  onGround: boolean;
  seenSec: number | null;
  aircraftType: string | null;
  registration: string | null;
}

export type FlightStatus =
  | 'IN FLIGHT'
  | 'CLIMBING'
  | 'DESCENDING'
  | 'ON GROUND'
  | 'POSITION STALE'
  | 'NOT TRACKED';

export interface FlightData {
  query: string;
  callsign: string;
  callsignIata?: string | null;
  airline?: AirlineInfo | null;
  origin: Airport | null;
  destination: Airport | null;
  live: LiveState | null;
  status: FlightStatus;
  fetchedAt: number;
}

export type LoadState =
  | { kind: 'idle' }
  | { kind: 'searching'; query: string }
  | { kind: 'error'; message: string; hint?: string }
  | { kind: 'active'; flight: FlightData };
