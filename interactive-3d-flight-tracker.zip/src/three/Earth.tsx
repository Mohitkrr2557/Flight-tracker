import { Component, type ReactNode } from 'react';
import * as THREE from 'three';
import { useTexture } from '@react-three/drei';
import { GLOBE_RADIUS } from '../lib/geo';

const DAY_URL = 'https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg';
const NIGHT_URL = 'https://unpkg.com/three-globe/example/img/earth-night.jpg';

useTexture.preload(DAY_URL);
useTexture.preload(NIGHT_URL);

const ATMOS_VERTEX = /* glsl */ `
  varying vec3 vNormal;
  void main() {
    vNormal = normalize(normalMatrix * normal);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const ATMOS_FRAGMENT = /* glsl */ `
  varying vec3 vNormal;
  void main() {
    float intensity = pow(0.66 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 4.0);
    gl_FragColor = vec4(0.28, 0.58, 1.0, 1.0) * intensity;
  }
`;

function TexturedEarth() {
  const [day, night] = useTexture([DAY_URL, NIGHT_URL]);
  return (
    <mesh>
      <sphereGeometry args={[GLOBE_RADIUS, 96, 96]} />
      <meshStandardMaterial
        map={day}
        emissiveMap={night}
        emissive="#cfe4ff"
        emissiveIntensity={0.42}
        roughness={1}
        metalness={0.04}
      />
    </mesh>
  );
}

function FallbackEarth() {
  return (
    <mesh>
      <sphereGeometry args={[GLOBE_RADIUS, 64, 64]} />
      <meshStandardMaterial color="#0a2748" roughness={0.9} metalness={0.1} />
    </mesh>
  );
}

class TextureBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? <FallbackEarth /> : this.props.children;
  }
}

export default function Earth() {
  return (
    <group>
      <TextureBoundary>
        <TexturedEarth />
      </TextureBoundary>

      {/* inner atmosphere rim */}
      <mesh scale={1.025}>
        <sphereGeometry args={[GLOBE_RADIUS, 64, 64]} />
        <meshBasicMaterial color="#1b4f9c" transparent opacity={0.12} side={THREE.BackSide} />
      </mesh>

      {/* fresnel glow */}
      <mesh scale={1.22}>
        <sphereGeometry args={[GLOBE_RADIUS, 64, 64]} />
        <shaderMaterial
          vertexShader={ATMOS_VERTEX}
          fragmentShader={ATMOS_FRAGMENT}
          blending={THREE.AdditiveBlending}
          side={THREE.BackSide}
          transparent
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}
