import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html, Line } from '@react-three/drei';
import type { Airport, FlightData } from '../types';
import {
  GLOBE_RADIUS,
  arcPoints,
  bearing,
  latLonToVec3,
  orientationAt,
} from '../lib/geo';
import PlaneModel from './PlaneModel';

/* ------------------------------------------------------------------ */

function AirportMarker({ airport, kind }: { airport: Airport; kind: 'origin' | 'destination' }) {
  const pos = useMemo(() => latLonToVec3(airport.lat, airport.lon, GLOBE_RADIUS * 1.004), [airport]);
  const color = kind === 'origin' ? '#38e1ff' : '#ffb454';
  return (
    <group position={pos}>
      <mesh>
        <sphereGeometry args={[0.02, 16, 16]} />
        <meshBasicMaterial color={color} />
      </mesh>
      <mesh quaternion={new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), pos.clone().normalize())}>
        <ringGeometry args={[0.038, 0.047, 32]} />
        <meshBasicMaterial color={color} transparent opacity={0.55} side={THREE.DoubleSide} />
      </mesh>
      <Html center zIndexRange={[30, 0]} style={{ pointerEvents: 'none' }}>
        <div className="translate-y-[-46px] whitespace-nowrap rounded-md border border-line bg-ink/85 px-2 py-1 text-center backdrop-blur-sm">
          <div className="font-mono text-[10px] font-bold tracking-[0.18em]" style={{ color }}>
            {airport.iata || airport.icao}
          </div>
          <div className="text-[9px] tracking-wide text-slate-300/80">
            {airport.city || airport.name}
          </div>
        </div>
      </Html>
    </group>
  );
}

/* ------------------------------------------------------------------ */

function PulseRing({ position, color = '#38e1ff' }: { position: THREE.Vector3; color?: string }) {
  const a = useRef<THREE.Mesh>(null);
  const b = useRef<THREE.Mesh>(null);
  const quat = useMemo(
    () => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), position.clone().normalize()),
    [position],
  );
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    [a, b].forEach((ref, i) => {
      const mesh = ref.current;
      if (!mesh) return;
      const phase = ((t * 0.6 + i * 0.5) % 1 + 1) % 1;
      const s = 0.06 + phase * 0.34;
      mesh.scale.setScalar(s);
      (mesh.material as THREE.MeshBasicMaterial).opacity = (1 - phase) * 0.65;
    });
  });
  return (
    <group position={position} quaternion={quat}>
      <mesh ref={a}>
        <ringGeometry args={[0.86, 1, 48]} />
        <meshBasicMaterial color={color} transparent opacity={0.6} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      <mesh ref={b}>
        <ringGeometry args={[0.86, 1, 48]} />
        <meshBasicMaterial color={color} transparent opacity={0.6} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */

function ScheduledArc({ from, to }: { from: Airport; to: Airport }) {
  const lineRef = useRef<any>(null);
  const pts = useMemo(() => arcPoints(from, to, 128, 0.17), [from, to]);
  useFrame((_, delta) => {
    if (lineRef.current?.material) {
      (lineRef.current.material as { dashOffset: number }).dashOffset -= delta * 0.12;
    }
  });
  return (
    <Line
      ref={lineRef}
      points={pts}
      color="#ffb454"
      lineWidth={1.6}
      dashed
      dashSize={0.09}
      gapSize={0.05}
      transparent
      opacity={0.85}
    />
  );
}

/* ------------------------------------------------------------------ */

export default function FlightViz({ flight }: { flight: FlightData }) {
  const { origin, destination, live } = flight;

  const hasPos = !!live && live.lat !== null && live.lon !== null;
  const airborne = hasPos && !live!.onGround;

  const planeLL = hasPos ? { lat: live!.lat!, lon: live!.lon! } : null;

  const altFrac = airborne ? Math.min(Math.max((live!.altitudeFt ?? 30000) / 47000, 0.04), 1) : 0;
  const altOffset = airborne ? 0.045 + altFrac * 0.34 : 0.014;

  const planePos = useMemo(
    () => (planeLL ? latLonToVec3(planeLL.lat, planeLL.lon, GLOBE_RADIUS * (1 + altOffset)) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [planeLL?.lat, planeLL?.lon, altOffset],
  );
  const surfacePos = useMemo(
    () => (planeLL ? latLonToVec3(planeLL.lat, planeLL.lon, GLOBE_RADIUS * 1.004) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [planeLL?.lat, planeLL?.lon],
  );

  const heading =
    live?.headingDeg ?? (planeLL && destination ? bearing(planeLL, destination) : 0);

  const quat = useMemo(
    () => (planePos ? orientationAt(planePos, heading) : new THREE.Quaternion()),
    [planePos, heading],
  );

  const forward = useMemo(
    () => new THREE.Vector3(0, 0, 1).applyQuaternion(quat),
    [quat],
  );

  const flownArc = useMemo(
    () => (origin && planeLL ? arcPoints(origin, planeLL, 72, Math.max(altOffset * 0.85, 0.05)) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [origin, planeLL?.lat, planeLL?.lon, altOffset],
  );

  const remainingArc = useMemo(
    () => (destination && planeLL ? arcPoints(planeLL, destination, 72, Math.max(altOffset * 0.85, 0.05)) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [destination, planeLL?.lat, planeLL?.lon, altOffset],
  );

  const rayEnd = useMemo(
    () => (planePos ? planePos.clone().add(forward.clone().multiplyScalar(0.42)) : null),
    [planePos, forward],
  );

  const coneQuat = useMemo(
    () => new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), forward),
    [forward],
  );

  return (
    <group>
      {origin && <AirportMarker airport={origin} kind="origin" />}
      {destination && <AirportMarker airport={destination} kind="destination" />}

      {/* scheduled / reference route when we have airports but no live fix */}
      {origin && destination && !planeLL && <ScheduledArc from={origin} to={destination} />}

      {/* flown leg — bright */}
      {flownArc && flownArc.length > 1 && (
        <>
          <Line points={flownArc} color="#38e1ff" lineWidth={7} transparent opacity={0.14} />
          <Line points={flownArc} color="#5ce9ff" lineWidth={2.2} transparent opacity={0.95} />
        </>
      )}

      {/* remaining leg — dashed */}
      {remainingArc && remainingArc.length > 1 && (
        <Line
          points={remainingArc}
          color="#ffb454"
          lineWidth={1.4}
          dashed
          dashSize={0.07}
          gapSize={0.045}
          transparent
          opacity={0.6}
        />
      )}

      {/* live aircraft */}
      {planePos && (
        <group>
          {/* altitude tether */}
          {surfacePos && (
            <Line
              points={[surfacePos, planePos]}
              color="#7dd3fc"
              lineWidth={1}
              transparent
              opacity={0.28}
              dashed
              dashSize={0.02}
              gapSize={0.015}
            />
          )}

          {/* ground shadow point + pulses */}
          {surfacePos && (
            <>
              <mesh position={surfacePos}>
                <sphereGeometry args={[0.014, 12, 12]} />
                <meshBasicMaterial color="#38e1ff" />
              </mesh>
              <PulseRing position={surfacePos} color={airborne ? '#38e1ff' : '#4ade9e'} />
            </>
          )}

          {/* heading ray */}
          {airborne && rayEnd && (
            <>
              <Line points={[planePos, rayEnd]} color="#67f6ff" lineWidth={2} transparent opacity={0.9} />
              <mesh position={rayEnd} quaternion={coneQuat}>
                <coneGeometry args={[0.02, 0.055, 10]} />
                <meshBasicMaterial color="#67f6ff" transparent opacity={0.9} />
              </mesh>
            </>
          )}

          {/* the plane */}
          <group position={planePos} quaternion={quat}>
            <PlaneModel scale={airborne ? 1 : 0.8} />
          </group>

          <Html position={planePos} center zIndexRange={[40, 0]} style={{ pointerEvents: 'none' }}>
            <div className="translate-y-[-58px] whitespace-nowrap rounded-md border border-amberx/30 bg-ink/90 px-2.5 py-1 text-center shadow-[0_0_24px_rgba(255,180,84,0.25)] backdrop-blur-sm">
              <div className="font-mono text-[11px] font-bold tracking-[0.2em] text-amberx">
                {flight.callsign}
              </div>
              <div className="font-mono text-[9px] tracking-wider text-slate-300/80">
                {airborne
                  ? `${Math.round(live!.altitudeFt ?? 0).toLocaleString()} FT · HDG ${Math.round(heading)}°`
                  : 'ON GROUND'}
              </div>
            </div>
          </Html>
        </group>
      )}
    </group>
  );
}
