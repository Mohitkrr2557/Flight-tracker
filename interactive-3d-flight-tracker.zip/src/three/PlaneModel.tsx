import { useMemo } from 'react';
import * as THREE from 'three';

let glowTexture: THREE.CanvasTexture | null = null;
export function getGlowTexture(): THREE.CanvasTexture {
  if (glowTexture) return glowTexture;
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255, 210, 140, 1)');
  g.addColorStop(0.25, 'rgba(255, 180, 84, 0.55)');
  g.addColorStop(0.6, 'rgba(255, 160, 60, 0.16)');
  g.addColorStop(1, 'rgba(255, 150, 50, 0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  glowTexture = new THREE.CanvasTexture(canvas);
  return glowTexture;
}

/**
 * Stylized low-poly airliner built from primitives.
 * Authored with nose = +Z, up = +Y so `orientationAt()` can aim it.
 */
export default function PlaneModel({ scale = 1 }: { scale?: number }) {
  const bodyMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: '#fff7ea',
        emissive: '#ffb454',
        emissiveIntensity: 0.35,
        roughness: 0.4,
        metalness: 0.35,
      }),
    [],
  );

  return (
    <group scale={scale}>
      {/* soft glow halo */}
      <sprite scale={[0.42, 0.42, 0.42]}>
        <spriteMaterial
          map={getGlowTexture()}
          transparent
          opacity={0.85}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </sprite>

      {/* fuselage (points +Z) */}
      <mesh rotation={[Math.PI / 2, 0, 0]} material={bodyMat}>
        <capsuleGeometry args={[0.016, 0.095, 6, 12]} />
      </mesh>

      {/* nose cone */}
      <mesh position={[0, 0, 0.075]} rotation={[Math.PI / 2, 0, 0]} material={bodyMat}>
        <coneGeometry args={[0.0155, 0.038, 12]} />
      </mesh>

      {/* main wings */}
      <mesh position={[0, 0, 0.012]} material={bodyMat}>
        <boxGeometry args={[0.19, 0.0045, 0.032]} />
      </mesh>

      {/* tailplane */}
      <mesh position={[0, 0.004, -0.062]} material={bodyMat}>
        <boxGeometry args={[0.068, 0.0035, 0.02]} />
      </mesh>

      {/* vertical stabilizer */}
      <mesh position={[0, 0.02, -0.06]} rotation={[0.32, 0, 0]} material={bodyMat}>
        <boxGeometry args={[0.0035, 0.036, 0.026]} />
      </mesh>
    </group>
  );
}
