import { Suspense, useRef, type ReactNode } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import type { FlightData } from '../types';
import { latLonToVec3 } from '../lib/geo';
import Earth from './Earth';
import FlightViz from './FlightViz';

export interface FocusPoint {
  lat: number;
  lon: number;
  seq: number; // bump to retrigger focus
}

/* Rotates the whole globe group: idle self-rotation, or swings the focused
   point to face the camera when a flight is selected. */
function SpinGroup({
  focus,
  children,
}: {
  focus: FocusPoint | null;
  children: ReactNode;
}) {
  const ref = useRef<THREE.Group>(null);
  const lastSeq = useRef(-1);
  const focusing = useRef(0); // seconds of recent focus action

  useFrame((_, dt) => {
    const g = ref.current;
    if (!g) return;
    const delta = Math.min(dt, 0.05);

    if (focus && focus.seq !== lastSeq.current) {
      lastSeq.current = focus.seq;
      focusing.current = 4; // glide for a few seconds, then hand control back
    }

    if (focus && focusing.current > 0) {
      focusing.current -= delta;
      const p = latLonToVec3(focus.lat, focus.lon, 1);
      const targetY = -Math.atan2(p.x, p.z);
      // shortest angular distance
      let dy = targetY - g.rotation.y;
      dy = THREE.MathUtils.euclideanModulo(dy + Math.PI, Math.PI * 2) - Math.PI;
      g.rotation.y += dy * (1 - Math.exp(-3.2 * delta));
      const targetX = Math.asin(THREE.MathUtils.clamp(p.y, -1, 1)) * 0.72;
      g.rotation.x = THREE.MathUtils.damp(g.rotation.x, targetX, 3.2, delta);
    } else if (!focus) {
      g.rotation.y += delta * 0.05;
      g.rotation.x = THREE.MathUtils.damp(g.rotation.x, 0.16, 2, delta);
    }
  });

  return <group ref={ref}>{children}</group>;
}

export default function GlobeCanvas({
  flight,
  focus,
}: {
  flight: FlightData | null;
  focus: FocusPoint | null;
}) {
  return (
    <Canvas
      camera={{ position: [2.2, 1.4, 4.6], fov: 40 }}
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: false }}
    >
      <color attach="background" args={['#02040a']} />

      <ambientLight intensity={0.42} />
      <directionalLight position={[6, 2.5, 4]} intensity={2.4} color="#eef4ff" />
      <directionalLight position={[-5, -2, -4]} intensity={0.35} color="#3d6bff" />

      <Stars radius={90} depth={50} count={3200} factor={4} saturation={0} fade speed={0.35} />

      <Suspense fallback={null}>
        <SpinGroup focus={focus}>
          <Earth />
          {flight && <FlightViz flight={flight} />}
        </SpinGroup>
      </Suspense>

      <OrbitControls
        makeDefault
        enablePan={false}
        enableDamping
        dampingFactor={0.07}
        rotateSpeed={0.55}
        minDistance={2.9}
        maxDistance={10}
      />
    </Canvas>
  );
}
