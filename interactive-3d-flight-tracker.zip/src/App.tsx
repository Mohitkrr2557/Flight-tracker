import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Crosshair, PanelLeftOpen, Radar } from 'lucide-react';
import GlobeCanvas, { type FocusPoint } from './three/GlobeCanvas';
import FlightPanel, { statusDotClass } from './components/FlightPanel';
import LiveMap from './components/LiveMap';
import { refreshLive, searchFlight } from './lib/flightApi';
import type { FlightData, LoadState } from './types';

const PANEL_MIN = 320;
const PANEL_MAX = 640;
const PANEL_DEFAULT = 400;

function ZuluClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="font-mono text-[11px] tracking-[0.2em] text-slate-300">
      {now.toISOString().slice(11, 19)}
      <span className="text-glow">Z</span>
    </span>
  );
}

export default function App() {
  const [state, setState] = useState<LoadState>({ kind: 'idle' });
  const [mapOpen, setMapOpen] = useState(false);
  const [focus, setFocus] = useState<FocusPoint | null>(null);
  const [panelWidth, setPanelWidth] = useState(PANEL_DEFAULT);
  const [collapsed, setCollapsed] = useState(false);
  const lastWidth = useRef(PANEL_DEFAULT);

  const collapsePanel = useCallback(() => {
    setPanelWidth((w) => {
      lastWidth.current = w;
      return w;
    });
    setCollapsed(true);
  }, []);

  const expandPanel = useCallback(() => {
    setPanelWidth((w) => (w < PANEL_MIN ? lastWidth.current || PANEL_DEFAULT : w));
    setCollapsed(false);
  }, []);

  const startResize = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      e.preventDefault();
      const startX = e.clientX;
      const startW = panelWidth;
      let currentW = startW;
      const onMove = (ev: MouseEvent) => {
        const next = Math.max(PANEL_MIN, Math.min(PANEL_MAX, startW + (ev.clientX - startX)));
        currentW = next;
        setPanelWidth(next);
      };
      const onUp = () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        // remember the latest width for expand-to-last-size
        lastWidth.current = currentW;
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
      document.body.style.cursor = 'ew-resize';
      document.body.style.userSelect = 'none';
    },
    [panelWidth],
  );

  const stateRef = useRef(state);
  stateRef.current = state;

  const activeFlight: FlightData | null = state.kind === 'active' ? state.flight : null;
  const hasPos =
    !!activeFlight?.live && activeFlight.live.lat !== null && activeFlight.live.lon !== null;

  const focusFlight = useCallback((flight: FlightData) => {
    const l = flight.live;
    const target =
      l && l.lat !== null && l.lon !== null
        ? { lat: l.lat, lon: l.lon }
        : flight.origin
          ? { lat: flight.origin.lat, lon: flight.origin.lon }
          : flight.destination
            ? { lat: flight.destination.lat, lon: flight.destination.lon }
            : null;
    if (target) setFocus((f) => ({ ...target, seq: (f?.seq ?? 0) + 1 }));
  }, []);

  const doSearch = useCallback(
    async (q: string) => {
      setState({ kind: 'searching', query: q });
      try {
        const flight = await searchFlight(q);
        if (!flight.live && !flight.origin && !flight.destination) {
          setState({
            kind: 'error',
            message: `NO SIGNAL FOR "${flight.callsign}"`,
            hint: 'That callsign is not in the live ADS-B feed or the route registry. If the flight is airborne right now, try both formats (e.g. UA123 and UAL123) — or check spelling.',
          });
          return;
        }
        setState({ kind: 'active', flight });
        focusFlight(flight);
      } catch {
        setState({
          kind: 'error',
          message: 'UPLINK FAILED',
          hint: 'The telemetry providers did not respond. Check your connection and try again.',
        });
      }
    },
    [focusFlight],
  );

  const doRefresh = useCallback(async () => {
    const s = stateRef.current;
    if (s.kind !== 'active') return;
    try {
      const next = await refreshLive(s.flight);
      setState((cur) =>
        cur.kind === 'active' && cur.flight.callsign === s.flight.callsign
          ? { kind: 'active', flight: next }
          : cur,
      );
    } catch {
      /* silent — next poll will retry */
    }
  }, []);

  /* live polling every 12 s while a flight is on screen */
  const activeCallsign = activeFlight?.callsign ?? null;
  useEffect(() => {
    if (!activeCallsign) return;
    const id = setInterval(async () => {
      const s = stateRef.current;
      if (s.kind !== 'active' || s.flight.callsign !== activeCallsign) return;
      try {
        const next = await refreshLive(s.flight);
        setState((cur) =>
          cur.kind === 'active' && cur.flight.callsign === activeCallsign
            ? { kind: 'active', flight: next }
            : cur,
        );
      } catch {
        /* transient network issue — keep last known fix */
      }
    }, 12000);
    return () => clearInterval(id);
  }, [activeCallsign]);

  return (
    <div className="relative h-full w-full overflow-hidden bg-abyss font-display text-slate-100">
      {/* 3D Earth — shifts right when panel is open on wide screens */}
      <div
        className={`absolute inset-y-0 left-0 right-0 z-0 transition-[left] duration-500 ease-[cubic-bezier(.22,1,.36,1)] ${
          collapsed ? '' : 'lg:left-[430px]'
        }`}
      >
        <GlobeCanvas flight={activeFlight} focus={focus} />
      </div>

      {/* atmosphere overlays */}
      <div className="grid-lines pointer-events-none absolute inset-0 z-[4]" />
      <div className="pointer-events-none absolute inset-0 z-[5] bg-[radial-gradient(ellipse_120%_90%_at_50%_50%,transparent_55%,rgba(2,4,10,0.75)_100%)]" />

      {/* header */}
      <header className="absolute inset-x-0 top-0 z-20 flex items-start justify-between p-5 sm:p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-glow/30 bg-glow/10 shadow-[0_0_28px_rgba(56,225,255,0.25)]">
            <Radar className="h-5 w-5 text-glow" strokeWidth={1.7} />
          </div>
          <div>
            <div className="bg-gradient-to-r from-white via-sky-200 to-glow bg-clip-text text-xl font-bold tracking-[0.3em] text-transparent">
              VECTOR
            </div>
            <div className="font-mono text-[8px] tracking-[0.32em] text-slate-400">
              LIVE FLIGHT INTELLIGENCE
            </div>
          </div>
        </div>
        <div className="hidden flex-col items-end gap-1 sm:flex">
          <ZuluClock />
          <div className="font-mono text-[8px] tracking-[0.22em] text-slate-500">
            ADS-B · adsb.lol — airplanes.live — adsbdb
          </div>
        </div>
      </header>

      {/* control / info panel — resizable + collapsible */}
      <AnimatePresence initial={false} mode="popLayout">
        {!collapsed && (
          <motion.aside
            key="tracker-panel"
            initial={{ opacity: 0, x: -28 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -28 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            style={{ width: panelWidth }}
            className="absolute bottom-5 left-4 top-[92px] z-20 sm:bottom-6 sm:left-6"
          >
            <div className="group relative h-full">
              <FlightPanel
                state={state}
                onSearch={doSearch}
                mapOpen={mapOpen}
                onToggleMap={() => setMapOpen((v) => !v)}
                onRefresh={doRefresh}
                onCollapse={collapsePanel}
              />

              {/* right-edge resize handle (desktop only) */}
              <div
                onMouseDown={startResize}
                role="separator"
                aria-orientation="vertical"
                aria-label="Resize flight tracker"
                className="absolute inset-y-6 -right-1.5 z-30 hidden w-3 cursor-ew-resize items-center justify-center rounded-full transition-colors hover:bg-glow/5 active:bg-glow/15 lg:flex"
              >
                <div className="h-12 w-0.5 rounded-full bg-glow/20 transition-all group-hover:h-20 group-hover:bg-glow/60" />
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* collapsed pill — opens the panel back up */}
      <AnimatePresence initial={false}>
        {collapsed && (
          <motion.button
            key="tracker-pill"
            type="button"
            onClick={expandPanel}
            initial={{ opacity: 0, scale: 0.9, x: -12 }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.92, x: -12 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="fixed bottom-5 left-4 z-30 flex items-center gap-2.5 rounded-full border border-glow/40 bg-ink/90 py-1.5 pl-1.5 pr-4 shadow-[0_0_30px_rgba(56,225,255,0.22)] backdrop-blur-md transition-all hover:border-glow/70 hover:shadow-[0_0_40px_rgba(56,225,255,0.35)] sm:bottom-6 sm:left-6"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-glow/15">
              <PanelLeftOpen className="h-3.5 w-3.5 text-glow" strokeWidth={2} />
            </div>
            <div className="flex flex-col items-start leading-none">
              <span className="font-mono text-[8px] font-bold tracking-[0.28em] text-slate-400">
                TRACKER
              </span>
              <span className="mt-0.5 font-mono text-[11px] font-bold tracking-[0.2em] text-white">
                {activeFlight?.callsign ?? 'OPEN'}
              </span>
            </div>
            {activeFlight && (
              <span
                className={`h-1.5 w-1.5 rounded-full ${statusDotClass(activeFlight.status)} animate-blink`}
              />
            )}
          </motion.button>
        )}
      </AnimatePresence>

      {/* recenter-on-aircraft button */}
      {activeFlight && hasPos && !mapOpen && (
        <button
          onClick={() => activeFlight && focusFlight(activeFlight)}
          className="fixed bottom-5 right-4 z-30 flex items-center gap-2 rounded-full border border-glow/40 bg-ink/80 px-4 py-2.5 font-mono text-[10px] font-bold tracking-[0.2em] text-glow backdrop-blur-md transition-all hover:bg-glow/15 sm:bottom-6 sm:right-6"
        >
          <Crosshair className="h-3.5 w-3.5" />
          FOCUS AIRCRAFT
        </button>
      )}

      {/* footer hint */}
      <div className="pointer-events-none absolute bottom-5 left-1/2 z-10 hidden -translate-x-1/2 font-mono text-[8px] tracking-[0.3em] text-slate-600 lg:block">
        DRAG TO ORBIT · SCROLL TO ZOOM
      </div>

      {/* 2D real map overlay */}
      <AnimatePresence>
        {mapOpen && activeFlight && (
          <LiveMap
            key={activeFlight.callsign}
            flight={activeFlight}
            onClose={() => setMapOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
