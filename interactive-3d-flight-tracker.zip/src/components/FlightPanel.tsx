import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  AlertTriangle,
  ArrowDownUp,
  Gauge,
  Map as MapIcon,
  Mountain,
  Navigation2,
  PanelLeftClose,
  Plane,
  Radio,
  RefreshCw,
  Satellite,
} from 'lucide-react';
import type { FlightData, FlightStatus, LoadState } from '../types';
import { arcProgress, cardinal, fmtCoord, fmtFpm, fmtFt, fmtKts } from '../lib/geo';
import SearchBar from './SearchBar';
import Compass from './Compass';

const SAMPLES = ['UAE20', 'BAW249', 'DAL402', 'QFA2', 'SIA322'];

export function statusDotClass(s: FlightStatus): string {
  switch (s) {
    case 'IN FLIGHT':
    case 'POSITION STALE':
    case 'NOT TRACKED':
      return 'bg-glow';
    case 'CLIMBING':
    case 'ON GROUND':
      return 'bg-mint';
    case 'DESCENDING':
      return 'bg-amberx';
    default:
      return 'bg-slate-400';
  }
}

function statusStyle(s: FlightStatus): { dot: string; text: string; ring: string } {
  switch (s) {
    case 'IN FLIGHT':
      return { dot: 'bg-glow', text: 'text-glow', ring: 'border-glow/40' };
    case 'CLIMBING':
      return { dot: 'bg-mint', text: 'text-mint', ring: 'border-mint/40' };
    case 'DESCENDING':
      return { dot: 'bg-amberx', text: 'text-amberx', ring: 'border-amberx/40' };
    case 'ON GROUND':
      return { dot: 'bg-mint', text: 'text-mint', ring: 'border-mint/40' };
    default:
      return { dot: 'bg-slate-400', text: 'text-slate-300', ring: 'border-slate-400/30' };
  }
}

function Stat({
  icon,
  label,
  value,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-lg border border-line bg-white/[0.02] px-3 py-2.5">
      <div className="mb-1 flex items-center gap-1.5 text-slate-400">
        {icon}
        <span className="text-[9px] font-bold tracking-[0.2em]">{label}</span>
      </div>
      <div className={`font-mono text-[13px] font-bold tracking-wide ${accent ? 'text-glow' : 'text-slate-100'}`}>
        {value}
      </div>
    </div>
  );
}

function RouteCard({ flight }: { flight: FlightData }) {
  const { origin, destination, live } = flight;
  const hasPos = live && live.lat !== null && live.lon !== null;
  const progress =
    origin && destination && hasPos
      ? arcProgress(origin, destination, { lat: live.lat!, lon: live.lon! })
      : null;

  return (
    <div className="rounded-xl border border-line bg-white/[0.02] p-4">
      {origin && destination ? (
        <>
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="font-mono text-2xl font-bold tracking-widest text-glow text-glow">
                {origin.iata || origin.icao}
              </div>
              <div className="mt-0.5 truncate text-[11px] text-slate-300/90">{origin.city}</div>
              <div className="truncate text-[9px] text-slate-500">{origin.name}</div>
            </div>
            <div className="mt-2 flex flex-1 flex-col items-center px-1">
              <Plane className="h-4 w-4 rotate-90 text-slate-400" strokeWidth={1.6} />
              <div className="mt-1 h-px w-full bg-gradient-to-r from-glow/60 via-slate-500/40 to-amberx/60" />
              {progress !== null && (
                <div className="mt-1 font-mono text-[9px] tracking-[0.2em] text-slate-400">
                  {Math.round(progress * 100)}% FLOWN
                </div>
              )}
            </div>
            <div className="min-w-0 text-right">
              <div className="font-mono text-2xl font-bold tracking-widest text-amberx">
                {destination.iata || destination.icao}
              </div>
              <div className="mt-0.5 truncate text-[11px] text-slate-300/90">{destination.city}</div>
              <div className="truncate text-[9px] text-slate-500">{destination.name}</div>
            </div>
          </div>
          {progress !== null && (
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-glow to-amberx transition-all duration-1000"
                style={{ width: `${Math.round(progress * 100)}%` }}
              />
            </div>
          )}
        </>
      ) : (
        <div className="text-[11px] leading-relaxed text-slate-400">
          No published route for this callsign right now — showing the live fix only.
        </div>
      )}
    </div>
  );
}

function ActiveView({
  flight,
  mapOpen,
  onToggleMap,
  onRefresh,
}: {
  flight: FlightData;
  mapOpen: boolean;
  onToggleMap: () => void;
  onRefresh: () => void;
}) {
  const st = statusStyle(flight.status);
  const live = flight.live;
  const hasPos = !!live && live.lat !== null && live.lon !== null;
  const airborne = hasPos && !live!.onGround;
  const heading = live?.headingDeg ?? null;

  const [ago, setAgo] = useState(0);
  useEffect(() => {
    setAgo(Math.max(0, Math.round((Date.now() - flight.fetchedAt) / 1000)));
    const id = setInterval(() => {
      setAgo(Math.max(0, Math.round((Date.now() - flight.fetchedAt) / 1000)));
    }, 1000);
    return () => clearInterval(id);
  }, [flight.fetchedAt]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col gap-3"
    >
      {/* identity */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <h2 className="font-mono text-3xl font-bold tracking-[0.12em] text-white">
              {flight.callsign}
            </h2>
            {flight.callsignIata && flight.callsignIata !== flight.callsign && (
              <span className="font-mono text-sm tracking-widest text-slate-400">
                / {flight.callsignIata}
              </span>
            )}
          </div>
          <div className="mt-0.5 truncate text-[11px] tracking-wide text-slate-400">
            {flight.airline?.name ?? 'Operator unknown'}
            {live?.registration ? ` · ${live.registration}` : ''}
          </div>
        </div>
        <div
          className={`flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 ${st.ring}`}
        >
          <span className={`h-1.5 w-1.5 rounded-full ${st.dot} animate-blink`} />
          <span className={`font-mono text-[9px] font-bold tracking-[0.18em] ${st.text}`}>
            {flight.status}
          </span>
        </div>
      </div>

      <RouteCard flight={flight} />

      {/* telemetry */}
      <div className="grid grid-cols-2 gap-2">
        <Stat icon={<Mountain className="h-3 w-3" />} label="ALTITUDE" value={fmtFt(live?.altitudeFt ?? null)} accent={airborne} />
        <Stat icon={<Gauge className="h-3 w-3" />} label="GND SPEED" value={fmtKts(live?.groundSpeedKts ?? null)} />
        <Stat
          icon={<Navigation2 className="h-3 w-3" />}
          label="HEADING"
          value={heading !== null ? `${Math.round(heading)}° ${cardinal(heading)}` : '—'}
          accent
        />
        <Stat icon={<ArrowDownUp className="h-3 w-3" />} label="VERT RATE" value={fmtFpm(live?.verticalRateFpm ?? null)} />
        <Stat icon={<Radio className="h-3 w-3" />} label="SQUAWK" value={live?.squawk ?? '—'} />
        <Stat icon={<Plane className="h-3 w-3" />} label="AIRFRAME" value={live?.aircraftType ?? '—'} />
      </div>

      {/* real world heading */}
      {hasPos && (
        <div className="flex items-center gap-4 rounded-xl border border-line bg-white/[0.02] p-4">
          <Compass heading={heading ?? 0} size={104} />
          <div className="min-w-0 flex-1">
            <div className="text-[9px] font-bold tracking-[0.22em] text-slate-400">
              REAL-WORLD HEADING
            </div>
            <div className="mt-1 font-mono text-xl font-bold text-white">
              {heading !== null ? `${Math.round(heading)}° — ${cardinal(heading)}` : 'ON THE GROUND'}
            </div>
            <div className="mt-1 text-[10px] leading-relaxed text-slate-400">
              {airborne
                ? `Nose pointed ${heading !== null ? cardinal(heading) : ''} true over ${fmtCoord(live!.lat, live!.lon)}`
                : `Parked / taxiing at ${fmtCoord(live!.lat, live!.lon)}`}
            </div>
          </div>
        </div>
      )}

      {flight.status === 'NOT TRACKED' && (
        <div className="flex gap-2.5 rounded-xl border border-amberx/25 bg-amberx/[0.06] p-3.5">
          <Satellite className="mt-0.5 h-4 w-4 shrink-0 text-amberx" />
          <p className="text-[11px] leading-relaxed text-amber-100/80">
            No live transponder fix for this callsign. It may have landed, be outside receiver
            coverage, or be scheduled later.{' '}
            {flight.origin && flight.destination && 'The dashed line shows its published route.'}
          </p>
        </div>
      )}

      {/* actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleMap}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg border px-3 py-2.5 font-mono text-[10px] font-bold tracking-[0.18em] transition-all ${
            mapOpen
              ? 'border-glow/50 bg-glow/15 text-glow'
              : 'border-line bg-white/[0.02] text-slate-300 hover:border-glow/40 hover:text-glow'
          }`}
        >
          <MapIcon className="h-3.5 w-3.5" />
          {mapOpen ? 'HIDE MAP' : 'REAL MAP'}
        </button>
        <button
          onClick={onRefresh}
          className="flex items-center justify-center gap-2 rounded-lg border border-line bg-white/[0.02] px-4 py-2.5 font-mono text-[10px] font-bold tracking-[0.18em] text-slate-300 transition-all hover:border-glow/40 hover:text-glow"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          REFRESH
        </button>
      </div>

      <div className="flex items-center justify-between font-mono text-[9px] tracking-[0.18em] text-slate-500">
        <span className="flex items-center gap-1.5">
          <span className={`h-1 w-1 rounded-full ${live ? 'bg-mint' : 'bg-slate-500'}`} />
          {live ? `ADS-B LIVE · UPDATED ${ago}S AGO` : 'AWAITING TRANSPONDER FIX'}
        </span>
        <span>TELEMETRY v2</span>
      </div>
    </motion.div>
  );
}

export default function FlightPanel({
  state,
  onSearch,
  mapOpen,
  onToggleMap,
  onRefresh,
  onCollapse,
}: {
  state: LoadState;
  onSearch: (q: string) => void;
  mapOpen: boolean;
  onToggleMap: () => void;
  onRefresh: () => void;
  onCollapse: () => void;
}) {
  return (
    <div className="glass flex max-h-full w-full flex-col gap-3 overflow-y-auto scroll-slim rounded-2xl p-4 pb-5">
      {/* panel chrome: identity + collapse */}
      <div className="flex items-center justify-between px-1 pt-0.5">
        <div className="flex items-center gap-2">
          <span className="h-1 w-1 rounded-full bg-glow animate-blink" />
          <span className="font-mono text-[9px] font-bold tracking-[0.28em] text-slate-400">
            FLIGHT TRACKER
          </span>
        </div>
        <button
          type="button"
          onClick={onCollapse}
          aria-label="Collapse tracker"
          title="Collapse to button"
          className="group flex h-7 w-7 items-center justify-center rounded-md border border-line bg-white/[0.02] text-slate-400 transition-all hover:border-glow/40 hover:text-glow"
        >
          <PanelLeftClose className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" strokeWidth={2} />
        </button>
      </div>

      <SearchBar onSearch={onSearch} loading={state.kind === 'searching'} />

      <AnimatePresence mode="wait">
        {state.kind === 'idle' && (
          <motion.div
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
          >
            <h1 className="mt-2 text-[26px] font-light leading-[1.12] tracking-tight text-slate-100">
              Any flight. <br />
              <span className="font-bold text-glow text-glow">A living Earth.</span>
            </h1>
            <p className="mt-3 text-[12px] leading-relaxed text-slate-400">
              Enter a flight number or callsign. We lock onto its live ADS-B transponder and place
              it on the globe — position, route, and the exact real-world heading it's flying right
              now.
            </p>
            <div className="mt-5">
              <div className="mb-2 text-[9px] font-bold tracking-[0.24em] text-slate-500">
                TRY SOMETHING AIRBORNE
              </div>
              <div className="flex flex-wrap gap-1.5">
                {SAMPLES.map((s) => (
                  <button
                    key={s}
                    onClick={() => onSearch(s)}
                    className="rounded-md border border-line bg-white/[0.03] px-2.5 py-1.5 font-mono text-[10px] tracking-widest text-slate-300 transition-all hover:border-glow/50 hover:text-glow"
                  >
                    {s}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[9px] tracking-wide text-slate-600">
                Samples only work while that flight is actually in the air.
              </p>
            </div>
          </motion.div>
        )}

        {state.kind === 'searching' && (
          <motion.div
            key="searching"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative mt-2 overflow-hidden rounded-xl border border-line bg-white/[0.02] p-8"
          >
            <div className="pointer-events-none absolute inset-x-0 top-0 h-1/4 animate-scan bg-gradient-to-b from-transparent via-glow/10 to-transparent" />
            <div className="flex flex-col items-center gap-3 text-center">
              <Satellite className="h-6 w-6 animate-blink text-glow" strokeWidth={1.5} />
              <div className="font-mono text-[11px] tracking-[0.28em] text-slate-300">
                INTERROGATING {state.query.toUpperCase()}
              </div>
              <div className="font-mono text-[9px] tracking-[0.18em] text-slate-500">
                ADS-B NETWORK + ROUTE DATABASE
              </div>
            </div>
          </motion.div>
        )}

        {state.kind === 'error' && (
          <motion.div
            key="error"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="mt-2 flex gap-3 rounded-xl border border-danger/30 bg-danger/[0.07] p-4"
          >
            <AlertTriangle className="mt-0.5 h-4.5 w-4.5 shrink-0 text-danger" strokeWidth={1.8} />
            <div>
              <div className="font-mono text-[12px] font-bold tracking-wider text-red-200">
                {state.message}
              </div>
              {state.hint && (
                <p className="mt-1.5 text-[11px] leading-relaxed text-red-100/60">{state.hint}</p>
              )}
            </div>
          </motion.div>
        )}

        {state.kind === 'active' && (
          <ActiveView
            key={state.flight.callsign}
            flight={state.flight}
            mapOpen={mapOpen}
            onToggleMap={onToggleMap}
            onRefresh={onRefresh}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
