import { useMemo } from 'react';

export default function Compass({ heading, size = 120 }: { heading: number; size?: number }) {
  const ticks = useMemo(() => Array.from({ length: 36 }, (_, i) => i * 10), []);
  const r = 52;

  return (
    <svg
      width={size}
      height={size}
      viewBox="-64 -64 128 128"
      aria-label={`Heading ${Math.round(heading)} degrees`}
    >
      <circle r={58} fill="rgba(10,18,36,0.6)" stroke="rgba(120,170,255,0.18)" strokeWidth={1} />

      {/* rotating card + needle together */}
      <g
        style={{
          transform: `rotate(${heading}deg)`,
          transformBox: 'fill-box',
          transformOrigin: 'center',
          transition: 'transform 0.9s cubic-bezier(.3,1.25,.45,1)',
        }}
      >
        {/* needle */}
        <polygon points="0,-44 5,0 -5,0" fill="#ffb454" />
        <polygon points="0,44 4,0 -4,0" fill="rgba(148,180,255,0.4)" />
      </g>

      {/* static ticks */}
      {ticks.map((deg) => {
        const major = deg % 90 === 0;
        const rad = ((deg - 90) * Math.PI) / 180;
        const x1 = Math.cos(rad) * (major ? r - 8 : r - 4);
        const y1 = Math.sin(rad) * (major ? r - 8 : r - 4);
        const x2 = Math.cos(rad) * r;
        const y2 = Math.sin(rad) * r;
        return (
          <line
            key={deg}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={major ? 'rgba(160,200,255,0.85)' : 'rgba(120,170,255,0.35)'}
            strokeWidth={major ? 1.6 : 1}
          />
        );
      })}

      {/* cardinal letters (static) */}
      {[
        { t: 'N', x: 0, y: -34, c: '#38e1ff' },
        { t: 'E', x: 36, y: 4, c: 'rgba(200,220,255,0.7)' },
        { t: 'S', x: 0, y: 42, c: 'rgba(200,220,255,0.7)' },
        { t: 'W', x: -36, y: 4, c: 'rgba(200,220,255,0.7)' },
      ].map((d) => (
        <text
          key={d.t}
          x={d.x}
          y={d.y}
          textAnchor="middle"
          dominantBaseline="middle"
          fill={d.c}
          fontSize={13}
          fontWeight={700}
          fontFamily="'JetBrains Mono', monospace"
        >
          {d.t}
        </text>
      ))}

      <circle r={3.4} fill="#e8f1ff" />
      <circle r={1.6} fill="#060b18" />
    </svg>
  );
}
