import { useState, type FormEvent } from 'react';
import { Plane, ScanSearch } from 'lucide-react';

export default function SearchBar({
  onSearch,
  loading,
}: {
  onSearch: (q: string) => void;
  loading: boolean;
}) {
  const [value, setValue] = useState('');

  const submit = (e?: FormEvent) => {
    e?.preventDefault();
    const q = value.trim();
    if (q) onSearch(q);
  };

  return (
    <form onSubmit={submit} className="relative">
      <div className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2">
        <Plane className="h-4.5 w-4.5 text-glow/70" strokeWidth={1.8} />
      </div>
      <input
        value={value}
        onChange={(e) => setValue(e.target.value.toUpperCase())}
        placeholder="FLIGHT NO. — e.g. UA123 or UAL123"
        spellCheck={false}
        autoComplete="off"
        className="w-full rounded-xl border border-line bg-ink/70 py-3.5 pl-11 pr-24 font-mono text-[13px] tracking-[0.14em] text-white placeholder:text-slate-500/70 outline-none backdrop-blur-md transition-all focus:border-glow/50 focus:shadow-[0_0_0_3px_rgba(56,225,255,0.12)]"
      />
      <button
        type="submit"
        disabled={loading || !value.trim()}
        className="absolute right-1.5 top-1/2 flex h-9 -translate-y-1/2 items-center gap-1.5 rounded-lg bg-glow/15 px-3.5 font-mono text-[11px] font-bold tracking-[0.16em] text-glow transition-all hover:bg-glow/25 disabled:cursor-not-allowed disabled:opacity-40"
      >
        <ScanSearch className="h-3.5 w-3.5" strokeWidth={2.2} />
        {loading ? (
          <span className="animate-blink">SCAN</span>
        ) : (
          'TRACK'
        )}
      </button>
    </form>
  );
}
