import { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, Marker, Polyline, TileLayer } from 'react-leaflet';
import L from 'leaflet';
import { motion } from 'framer-motion';
import { LocateFixed, Map as MapIcon, Satellite, Train, X } from 'lucide-react';
import type { FlightData } from '../types';
import { unwrapLon } from '../lib/geo';

type ViewStyle = 'explore' | 'satellite' | 'transit';

type TileSpec = {
  label: string;
  url: string;
  attribution: string;
  Icon: typeof MapIcon;
};

// Free, keyless tile providers. Each mirrors the style language of Apple Maps' view modes.
const TILES: Record<ViewStyle, TileSpec> = {
  explore: {
    label: 'Explore',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
    Icon: MapIcon,
  },
  satellite: {
    label: 'Satellite',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution:
      'Tiles &copy; Esri &mdash; Source: Esri, Earthstar Geographics, and the GIS User Community',
    Icon: Satellite,
  },
  transit: {
    label: 'Transit',
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
    Icon: Train,
  },
};

const VIEW_ORDER: ViewStyle[] = ['explore', 'satellite', 'transit'];

function ViewSwitcher({
  value,
  onChange,
}: {
  value: ViewStyle;
  onChange: (v: ViewStyle) => void;
}) {
  return (
    <div
      role="tablist"
      aria-label="Map view"
      className="flex items-center rounded-full border border-line bg-ink/85 p-0.5 shadow-[0_0_18px_rgba(0,0,0,0.5)] backdrop-blur-md"
    >
      {VIEW_ORDER.map((opt) => {
        const { label, Icon } = TILES[opt];
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(opt)}
            className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[9px] font-bold tracking-[0.18em] transition-all ${
              active
                ? 'bg-glow/20 text-glow shadow-[0_0_12px_rgba(56,225,255,0.25)]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className="h-3 w-3" strokeWidth={active ? 2.4 : 2} />
            <span className="hidden min-[380px]:inline">{label.toUpperCase()}</span>
          </button>
        );
      })}
    </div>
  );
}

function planeIcon(headingDeg: number): L.DivIcon {
  return L.divIcon({
    className: 'flight-pin',
    iconSize: [30, 30],
    iconAnchor: [15, 15],
    html: `
      <div style="
        width:30px;height:30px;display:flex;align-items:center;justify-content:center;
        filter: drop-shadow(0 0 6px rgba(255,180,84,0.8));
        transform: rotate(${headingDeg}deg); transition: transform 0.8s ease;">
        <svg width="26" height="26" viewBox="0 0 24 24">
          <path d="M12 1.5c1.4 2.6 1.9 5 1.9 7l6.1 4v2.1l-6.1-1.8c0 1.8-.3 3.6-.9 4.9l1.9 2.3v2l-2.9-.8-2.9.8v-2l1.9-2.3c-.6-1.3-.9-3.1-.9-4.9L4 14.6v-2.1l6.1-4c0-2 .5-4.4 1.9-7z"
            fill="#ffb454" stroke="#120a02" stroke-width="1"/>
        </svg>
      </div>`,
  });
}

function airportIcon(color: string, code: string): L.DivIcon {
  return L.divIcon({
    className: 'flight-pin',
    iconSize: [26, 26],
    iconAnchor: [13, 13],
    html: `
      <div style="display:flex;flex-direction:column;align-items:center;gap:2px;transform:translateY(-6px)">
        <div style="
          width:12px;height:12px;border-radius:50%;
          background:${color};border:2px solid rgba(255,255,255,0.85);
          box-shadow:0 0 10px ${color};"></div>
        <div style="
          font:700 9px 'JetBrains Mono',monospace;letter-spacing:1px;
          color:#e8f1ff;background:rgba(6,11,24,0.85);padding:1px 5px;border-radius:4px;
          border:1px solid rgba(120,170,255,0.25);">${code}</div>
      </div>`,
  });
}

export default function LiveMap({
  flight,
  onClose,
}: {
  flight: FlightData;
  onClose: () => void;
}) {
  const mapRef = useRef<L.Map | null>(null);
  const [viewStyle, setViewStyle] = useState<ViewStyle>('explore');
  const tile = TILES[viewStyle];

  const { origin, destination, live } = flight;
  const hasPos = !!live && live.lat !== null && live.lon !== null;
  const heading = live?.headingDeg ?? 0;

  const planeLL: [number, number] | null = hasPos ? [live!.lat!, live!.lon!] : null;

  const flownPath = useMemo(() => {
    if (!origin || !planeLL) return null;
    const pts: [number, number][] = [
      [origin.lat, origin.lon],
      [planeLL[0], unwrapLon(origin.lon, planeLL[1])],
    ];
    return pts;
  }, [origin, planeLL?.[0], planeLL?.[1]]); // eslint-disable-line react-hooks/exhaustive-deps

  const remainingPath = useMemo(() => {
    if (!destination || !planeLL) return null;
    const pts: [number, number][] = [
      planeLL,
      [destination.lat, unwrapLon(planeLL[1], destination.lon)],
    ];
    return pts;
  }, [destination, planeLL?.[0], planeLL?.[1]]); // eslint-disable-line react-hooks/exhaustive-deps

  const plannedPath = useMemo(() => {
    if (!origin || !destination || planeLL) return null;
    return [
      [origin.lat, origin.lon],
      [destination.lat, unwrapLon(origin.lon, destination.lon)],
    ] as [number, number][];
  }, [origin, destination, planeLL]); // eslint-disable-line react-hooks/exhaustive-deps

  // fit everything into view when the flight (callsign) changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const pts: L.LatLngExpression[] = [];
    if (origin) pts.push([origin.lat, origin.lon]);
    if (destination) pts.push([destination.lat, destination.lon]);
    if (planeLL) pts.push(planeLL);
    if (pts.length > 0) {
      map.fitBounds(L.latLngBounds(pts), { padding: [44, 44], maxZoom: 6, animate: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [flight.callsign]);

  const recenter = () => {
    const map = mapRef.current;
    if (map && planeLL) map.flyTo(planeLL, Math.max(map.getZoom(), 4), { duration: 0.8 });
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 32, scale: 0.98 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: 32, scale: 0.98 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="pointer-events-auto fixed bottom-4 right-4 z-40 h-[44vh] w-[min(440px,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-line shadow-[0_24px_80px_rgba(0,0,0,0.6)] sm:bottom-6 sm:right-6 sm:h-[50vh]"
    >
      <MapContainer
        ref={mapRef}
        center={planeLL ?? [25, 10]}
        zoom={4}
        zoomControl={false}
        attributionControl
        className="h-full w-full"
        worldCopyJump
      >
        <TileLayer key={viewStyle} url={tile.url} attribution={tile.attribution} />

        {plannedPath && (
          <Polyline positions={plannedPath} pathOptions={{ color: '#ffb454', weight: 2, opacity: 0.7, dashArray: '6 8' }} />
        )}
        {flownPath && (
          <Polyline positions={flownPath} pathOptions={{ color: '#38e1ff', weight: 3, opacity: 0.95 }} />
        )}
        {remainingPath && (
          <Polyline positions={remainingPath} pathOptions={{ color: '#ffb454', weight: 2, opacity: 0.75, dashArray: '5 7' }} />
        )}

        {origin && (
          <Marker position={[origin.lat, origin.lon]} icon={airportIcon('#38e1ff', origin.iata || origin.icao)} />
        )}
        {destination && (
          <Marker
            position={[destination.lat, destination.lon]}
            icon={airportIcon('#ffb454', destination.iata || destination.icao)}
          />
        )}
        {planeLL && <Marker position={planeLL} icon={planeIcon(heading)} zIndexOffset={500} />}
      </MapContainer>

      {/* header: title + view switcher + controls */}
      <div className="pointer-events-none absolute left-0 right-0 top-0 z-[500] flex flex-col gap-2 bg-gradient-to-b from-abyss/90 via-abyss/60 to-transparent px-3.5 pb-6 pt-2.5">
        <div className="flex items-start justify-between gap-2">
          <div className="pointer-events-auto">
            <div className="font-mono text-[10px] font-bold tracking-[0.24em] text-glow">
              REAL-WORLD MAP
            </div>
            <div className="font-mono text-[9px] tracking-[0.14em] text-slate-400">
              {flight.callsign}
              {live?.altitudeFt != null ? ` · ${Math.round(live.altitudeFt).toLocaleString()} FT` : ''}
            </div>
          </div>
          <div className="pointer-events-auto flex items-center gap-1.5">
            {planeLL && (
              <button
                onClick={recenter}
                className="rounded-md border border-line bg-ink/85 p-1.5 text-slate-300 backdrop-blur transition-colors hover:text-glow"
                aria-label="Recenter on aircraft"
              >
                <LocateFixed className="h-3.5 w-3.5" />
              </button>
            )}
            <button
              onClick={onClose}
              className="rounded-md border border-line bg-ink/85 p-1.5 text-slate-300 backdrop-blur transition-colors hover:text-danger"
              aria-label="Close map"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        <div className="pointer-events-auto flex justify-center">
          <ViewSwitcher value={viewStyle} onChange={setViewStyle} />
        </div>
      </div>
    </motion.div>
  );
}
