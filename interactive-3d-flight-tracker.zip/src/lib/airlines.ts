// IATA (2-char) -> ICAO (3-char) airline designators for common carriers.
// Used to normalize user input like "UA123" into the ICAO callsign "UAL123"
// that ADS-B transponders actually broadcast.
export const IATA_TO_ICAO: Record<string, string> = {
  AA: 'AAL', UA: 'UAL', DL: 'DAL', BA: 'BAW', AF: 'AFR', LH: 'DLH', KL: 'KLM',
  QF: 'QFA', EK: 'UAE', QR: 'QTR', SQ: 'SIA', CX: 'CPA', NH: 'ANA', JL: 'JAL',
  TK: 'THY', AC: 'ACA', WN: 'SWA', NK: 'NKS', B6: 'JBU', AS: 'ASA', NZ: 'ANZ',
  VS: 'VIR', AZ: 'ITY', IB: 'IBE', LX: 'SWR', OS: 'AUA', TP: 'TAP', EI: 'EIN',
  SK: 'SAS', AY: 'FIN', LO: 'LOT', SU: 'AFL', KE: 'KAL', OZ: 'AAR', CI: 'CAL',
  BR: 'EVA', TG: 'THA', MH: 'MAS', GA: 'GIA', PR: 'PAL', VN: 'HVN', AI: 'AIC',
  ET: 'ETH', MS: 'MSR', SA: 'SAA', LA: 'LAN', AV: 'AVA', CM: 'CMP', AR: 'ARG',
  AM: 'AMX', F9: 'FFT', HA: 'HAL', WS: 'WJA', PD: 'POE', FR: 'RYR', U2: 'EZY',
  W6: 'WZZ', DY: 'NOZ', VY: 'VLG', EY: 'ETD', SV: 'SVA', GF: 'GFA', KU: 'KAC',
  RJ: 'RJA', ME: 'MEA', UL: 'ALK', CA: 'CCA', MU: 'CES', CZ: 'CSN', HU: 'CHH',
  FM: 'CSH', ZH: 'CSZ', SC: 'CDG', MF: 'CXA', HO: 'DKH', '3U': 'CSC', FD: 'AIQ',
  SL: 'TLM', XQ: 'SXS', PC: 'PGT', FI: 'ICE', BT: 'BTI', OK: 'CSA', RO: 'ROT',
  SN: 'BEL', KM: 'AMC', PK: 'PIA', Biman: 'BBC', IT: 'ITY', WK: 'EDW', A3: 'AEE',
  JU: 'ASL', OU: 'CTN', LY: 'ELY', WY: 'OMA', HM: 'SEY', KQ: 'KQA', TN: 'THT',
  SB: 'ACI', FJ: 'FJI', BI: 'RBA', KM2: 'AMC', PG: 'BKP', DE: 'CFG', EW: 'EWG',
  VO: 'VOT', G3: 'GLO', AD: 'AZU', JJ: 'TAM', '4O': 'AIJ', VB: 'VIV', Y4: 'VOI',
  H2: 'SKU', JA: 'JCH', SE: 'XLF', X7: 'CRK', '6E': 'IGO', SG: 'SEJ', UK: 'VTI',
  QP: 'AKJ', IX: 'AXB', G9: 'ABY', FZ: 'FDB', XY: 'KNE', J9: 'JZR', WY2: 'OMA',
};

export function normalizeCallsignVariants(raw: string): string[] {
  const clean = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!clean) return [];
  const variants: string[] = [clean];

  // Split into alpha prefix + numeric suffix
  const m = clean.match(/^([A-Z]{1,3})([0-9][A-Z0-9]{0,4})$/);
  if (m) {
    const [, prefix, rest] = m;
    const icao = IATA_TO_ICAO[prefix];
    if (icao) {
      variants.push(icao + rest);
      variants.push(icao + rest.replace(/^0+/, '')); // drop leading zeros in flight number
    }
  }
  // Sometimes people paste ICAO with space already handled; also try trimming trailing letters
  return Array.from(new Set(variants));
}
