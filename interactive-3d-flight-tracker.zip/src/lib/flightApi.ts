import type { AirlineInfo, Airport, FlightData, FlightStatus, LiveState } from '../types';
import { normalizeCallsignVariants } from './airlines';

/* ------------------------------------------------------------------ */
/*  Data sources (both free + CORS enabled):                           */
/*  • adsb.lol / airplanes.live — live ADS-B positions by callsign     */
/*  • adsbdb.com            — route lookup (origin / destination)      */
/* ------------------------------------------------------------------ */

const LIVE_SOURCES = [
  (cs: string) => `https://api.adsb.lol/v2/callsign/${cs}`,
  (cs: string) => `https://api.airplanes.live/v2/callsign/${cs}`,
  (cs: string) => `https://api.adsb.one/v2/callsign/${cs}`,
];

const ROUTE_URL = (cs: string) => `https://api.adsbdb.com/v0/callsign/${cs}`;

async function fetchJson(url: string, timeoutMs = 9000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

/* ------------------------------ parsing --------------------------- */

interface RawAc {
  hex?: string;
  flight?: string;
  lat?: number;
  lon?: number;
  alt_baro?: number | 'ground' | null;
  gs?: number | null;
  track?: number | null;
  true_heading?: number | null;
  baro_rate?: number | null;
  squawk?: string | null;
  seen_pos?: number | null;
  seen?: number | null;
  t?: string | null;
  r?: string | null;
}

function parseLive(ac: RawAc): LiveState {
  const onGround = ac.alt_baro === 'ground';
  const alt =
    typeof ac.alt_baro === 'number' ? ac.alt_baro : onGround ? 0 : null;
  return {
    icao24: ac.hex ?? '',
    lat: typeof ac.lat === 'number' ? ac.lat : null,
    lon: typeof ac.lon === 'number' ? ac.lon : null,
    altitudeFt: alt,
    groundSpeedKts: typeof ac.gs === 'number' ? ac.gs : null,
    headingDeg:
      typeof ac.track === 'number'
        ? ac.track
        : typeof ac.true_heading === 'number'
          ? ac.true_heading
          : null,
    verticalRateFpm: typeof ac.baro_rate === 'number' ? ac.baro_rate : null,
    squawk: ac.squawk ?? null,
    onGround,
    seenSec: typeof ac.seen_pos === 'number' ? ac.seen_pos : ac.seen ?? null,
    aircraftType: ac.t ?? null,
    registration: ac.r ?? null,
  };
}

interface RawAirport {
  iata_code?: string;
  icao_code?: string;
  name?: string;
  municipality?: string;
  country_name?: string;
  latitude?: number;
  longitude?: number;
}

function parseAirport(a?: RawAirport | null): Airport | null {
  if (!a || typeof a.latitude !== 'number' || typeof a.longitude !== 'number') return null;
  return {
    iata: a.iata_code ?? '',
    icao: a.icao_code ?? '',
    name: a.name ?? '',
    city: a.municipality ?? '',
    country: a.country_name ?? '',
    lat: a.latitude,
    lon: a.longitude,
  };
}

function statusFromLive(live: LiveState): FlightStatus {
  if (live.onGround) return 'ON GROUND';
  if (live.lat === null || live.lon === null) return 'POSITION STALE';
  const vr = live.verticalRateFpm ?? 0;
  if (vr > 400) return 'CLIMBING';
  if (vr < -400) return 'DESCENDING';
  return 'IN FLIGHT';
}

/* ------------------------------ lookups --------------------------- */

async function lookupLive(callsigns: string[]): Promise<{ live: LiveState; callsign: string } | null> {
  for (const cs of callsigns) {
    for (const makeUrl of LIVE_SOURCES) {
      try {
        const json = (await fetchJson(makeUrl(cs))) as { ac?: RawAc[] };
        const ac = json?.ac;
        if (Array.isArray(ac) && ac.length > 0) {
          // prefer the entry that actually has a position
          const best = ac.find((a) => typeof a.lat === 'number') ?? ac[0];
          return { live: parseLive(best), callsign: (best.flight ?? cs).trim() || cs };
        }
      } catch {
        /* try next source */
      }
    }
  }
  return null;
}

interface RouteResult {
  origin: Airport | null;
  destination: Airport | null;
  airline: AirlineInfo | null;
  callsignIata: string | null;
  callsignIcao: string | null;
}

async function lookupRoute(callsigns: string[]): Promise<RouteResult | null> {
  for (const cs of callsigns) {
    try {
      const json = (await fetchJson(ROUTE_URL(cs))) as {
        response?: {
          flightroute?: {
            callsign_icao?: string;
            callsign_iata?: string;
            airline?: { name?: string; iata?: string; icao?: string; country?: string };
            origin?: RawAirport;
            destination?: RawAirport;
          };
        } | string;
      };
      const resp = json?.response;
      if (resp && typeof resp !== 'string' && resp.flightroute) {
        const fr = resp.flightroute;
        return {
          origin: parseAirport(fr.origin),
          destination: parseAirport(fr.destination),
          airline: fr.airline
            ? {
                name: fr.airline.name ?? '',
                iata: fr.airline.iata ?? null,
                icao: fr.airline.icao ?? null,
                country: fr.airline.country ?? null,
              }
            : null,
          callsignIata: fr.callsign_iata ?? null,
          callsignIcao: fr.callsign_icao ?? cs,
        };
      }
    } catch {
      /* route unknown */
    }
  }
  return null;
}

/* ------------------------------ public ---------------------------- */

export async function searchFlight(query: string): Promise<FlightData> {
  const variants = normalizeCallsignVariants(query);
  if (variants.length === 0) throw new Error('EMPTY');

  const [liveHit, route] = await Promise.all([lookupLive(variants), lookupRoute(variants)]);

  const callsign = liveHit?.callsign ?? route?.callsignIcao ?? variants[variants.length - 1];

  let status: FlightStatus;
  if (liveHit) status = statusFromLive(liveHit.live);
  else status = 'NOT TRACKED';

  return {
    query,
    callsign,
    callsignIata: route?.callsignIata ?? null,
    airline: route?.airline ?? null,
    origin: route?.origin ?? null,
    destination: route?.destination ?? null,
    live: liveHit?.live ?? null,
    status,
    fetchedAt: Date.now(),
  };
}

/** Lightweight refresh of only the live position (for polling). */
export async function refreshLive(flight: FlightData): Promise<FlightData> {
  const variants = normalizeCallsignVariants(flight.callsign);
  const hit = await lookupLive(variants);
  if (!hit) {
    return { ...flight, live: null, status: 'NOT TRACKED', fetchedAt: Date.now() };
  }
  return {
    ...flight,
    live: hit.live,
    callsign: hit.callsign,
    status: statusFromLive(hit.live),
    fetchedAt: Date.now(),
  };
}
