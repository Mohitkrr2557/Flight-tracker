import * as THREE from 'three';

export const GLOBE_RADIUS = 2;

/** Convert latitude/longitude to a point on the globe sphere. */
export function latLonToVec3(lat: number, lon: number, radius: number = GLOBE_RADIUS): THREE.Vector3 {
  const phi = ((90 - lat) * Math.PI) / 180;
  const theta = ((lon + 180) * Math.PI) / 180;
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta),
  );
}

/** Spherical interpolation between two unit-ish vectors (great circle). */
export function slerp(a: THREE.Vector3, b: THREE.Vector3, t: number): THREE.Vector3 {
  const angle = a.angleTo(b);
  if (angle < 1e-6) return a.clone();
  const sinTotal = Math.sin(angle);
  const ratioA = Math.sin((1 - t) * angle) / sinTotal;
  const ratioB = Math.sin(t * angle) / sinTotal;
  return a.clone().multiplyScalar(ratioA).add(b.clone().multiplyScalar(ratioB));
}

/** Great-circle point at parameter t (0..1) between two lat/lon points, lifted above surface. */
export function arcPoint(
  from: { lat: number; lon: number },
  to: { lat: number; lon: number },
  t: number,
  lift: number,
): THREE.Vector3 {
  const a = latLonToVec3(from.lat, from.lon);
  const b = latLonToVec3(to.lat, to.lon);
  const p = slerp(a, b, t).normalize();
  // Altitude profile peaks mid-route; scale by chord length so short hops stay lower
  const chord = a.distanceTo(b) / (2 * GLOBE_RADIUS); // 0..1
  const h = Math.sin(Math.PI * t) * lift * (0.25 + chord * 0.75);
  return p.multiplyScalar(GLOBE_RADIUS * (1 + h));
}

export function arcPoints(
  from: { lat: number; lon: number },
  to: { lat: number; lon: number },
  segments = 100,
  lift = 0.16,
): THREE.Vector3[] {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= segments; i++) pts.push(arcPoint(from, to, i / segments, lift));
  return pts;
}

/** Progress (0..1) of `pos` along the great-circle from `from` to `to`, by angular ratio. */
export function arcProgress(
  from: { lat: number; lon: number },
  to: { lat: number; lon: number },
  pos: { lat: number; lon: number },
): number {
  const a = latLonToVec3(from.lat, from.lon);
  const b = latLonToVec3(to.lat, to.lon);
  const p = latLonToVec3(pos.lat, pos.lon);
  const total = a.angleTo(b);
  if (total < 1e-6) return 0;
  return THREE.MathUtils.clamp(a.angleTo(p) / total, 0, 1);
}

/**
 * Quaternion that orients an object at `position` on the sphere so that its
 * nose (+Z) points along `headingDeg` (0 = north, 90 = east) and its up stays
 * radial. Objects authored with forward = +Z.
 */
export function orientationAt(position: THREE.Vector3, headingDeg: number): THREE.Quaternion {
  const up = position.clone().normalize();
  // Local east = cross(worldNorthPole, up); guard at poles
  let east = new THREE.Vector3(0, 1, 0).cross(up);
  if (east.lengthSq() < 1e-8) east = new THREE.Vector3(1, 0, 0);
  east.normalize();
  const north = up.clone().cross(east).normalize(); // actually up x east = north? verify sign below

  // north should point toward increasing latitude. up x east gives north for ENU frame when east = y_world x up.
  const h = (headingDeg * Math.PI) / 180;
  const dir = north.multiplyScalar(Math.cos(h)).add(east.multiplyScalar(Math.sin(h))).normalize();

  // Orthonormal basis: z = forward, y = up, x = y x z
  const zAxis = dir;
  const yAxis = up;
  const x2 = new THREE.Vector3().crossVectors(yAxis, zAxis).normalize();
  const y2 = new THREE.Vector3().crossVectors(zAxis, x2).normalize();

  const m = new THREE.Matrix4().makeBasis(x2, y2, zAxis);
  return new THREE.Quaternion().setFromRotationMatrix(m);
}

/** Initial bearing from point A to B (degrees true). */
export function bearing(from: { lat: number; lon: number }, to: { lat: number; lon: number }): number {
  const f1 = (from.lat * Math.PI) / 180;
  const f2 = (to.lat * Math.PI) / 180;
  const dL = ((to.lon - from.lon) * Math.PI) / 180;
  const y = Math.sin(dL) * Math.cos(f2);
  const x = Math.cos(f1) * Math.sin(f2) - Math.sin(f1) * Math.cos(f2) * Math.cos(dL);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

const CARDINALS = [
  'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
  'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW',
];

export function cardinal(deg: number): string {
  return CARDINALS[Math.round(deg / 22.5) % 16];
}

/** Adjust destination longitude for 2D maps so the drawn line takes the short way. */
export function unwrapLon(fromLon: number, toLon: number): number {
  let d = toLon - fromLon;
  while (d > 180) { toLon -= 360; d = toLon - fromLon; }
  while (d < -180) { toLon += 360; d = toLon - fromLon; }
  return toLon;
}

export function fmtFt(ft: number | null): string {
  if (ft === null || Number.isNaN(ft)) return '—';
  return `${Math.round(ft).toLocaleString('en-US')} FT`;
}

export function fmtKts(kts: number | null): string {
  if (kts === null || Number.isNaN(kts)) return '—';
  return `${Math.round(kts)} KT`;
}

export function fmtFpm(fpm: number | null): string {
  if (fpm === null || Number.isNaN(fpm)) return '—';
  const v = Math.round(fpm);
  return `${v > 0 ? '+' : ''}${v.toLocaleString('en-US')} FPM`;
}

export function fmtCoord(lat: number | null, lon: number | null): string {
  if (lat === null || lon === null) return '—';
  const la = `${Math.abs(lat).toFixed(3)}° ${lat >= 0 ? 'N' : 'S'}`;
  const lo = `${Math.abs(lon).toFixed(3)}° ${lon >= 0 ? 'E' : 'W'}`;
  return `${la}  ${lo}`;
}
